from setuptools import setup

setup(name='gg_dist',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['gg_dist'],
      author='Goutam Kumar Ghadai',
      author_email='goutam.ghadai2199@gmail.com',
      zip_safe=False)
